/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package belajar_class_method;

/**
 *
 * @author EC
 */
public class book {
    private int price;
    private int pages;

    public void set(int price, int pages) {
        this.price = price;
        this.pages = pages;
    }

    public void show() {
        System.out.println("Books information");
        System.out.println("Books price: $" + price);
        System.out.println("Number of pages: " + pages);
    }
}

public class Buku {
    public static void main(String[] args) {
        book javabook = new book();
        javabook.set(1000000, 2000);
        javabook.show();
    }
}
