/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package belajar_class_method;

/**
 *
 * @author EC
 */
public class person {
  // Deklarasi bidang
  private String name;
  private int age;

  // Konstruktor
  public person(String name, int age) {
    this.name = name;
    this.age = age;
  }

  // Metode get
  public String getName() {
    return name;
  }

  public int getAge() {
    return age;
  }

  // Metode set
  public void setName(String name) {
    this.name = name;
  }

  public void setAge(int age) {
    this.age = age;
  }
}
