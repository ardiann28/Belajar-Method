/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package belajar_class_method;

import java.util.Scanner;

/**
 *
 * @author EC
 */
public class promo_belanja {
    public static void main(String[] args) {
        // Membuat objek Scanner untuk mengambil input dari pengguna
        Scanner sc = new Scanner(System.in);

        // Membuat variabel untuk menyimpan nama pembeli, harga barang, total harga, dan hadiah
        String nama;
        int harga1, harga2, harga3, harga4, harga5;
        int totalHarga;
        String hadiah;

        // Menampilkan informasi promo
        System.out.println("Kharisna Agung Plaza (KAP) > Promo Belanja Berhadiah");
        System.out.println("Khusus Pembelian 5 Barang Pertama Dengan harga minimum Rp 18000.00");

        // Meminta input nama pembeli
        System.out.print("Masukkan nama pembeli: ");
        nama = sc.nextLine();

        // Meminta input harga barang ke-1
        System.out.print("Masukkan harga barang ke-1: ");
        harga1 = sc.nextInt();

        // Meminta input harga barang ke-2
        System.out.print("Masukkan harga barang ke-2: ");
        harga2 = sc.nextInt();

        // Meminta input harga barang ke-3
        System.out.print("Masukkan harga barang ke-3: ");
        harga3 = sc.nextInt();

        // Meminta input harga barang ke-4
        System.out.print("Masukkan harga barang ke-4: ");
        harga4 = sc.nextInt();

        // Meminta input harga barang ke-5
        System.out.print("Masukkan harga barang ke-5: ");
        harga5 = sc.nextInt();

        // Menghitung total harga pembelian
        totalHarga = harga1 + harga2 + harga3 + harga4 + harga5;

        // Menampilkan total harga pembelian
        System.out.println("Total harga pembelian atas nama " + nama + " adalah Rp " + totalHarga);

        // Menentukan hadiah berdasarkan total harga
        if (totalHarga >= 18000) {
            hadiah = "1 buah mug cantik";
        } else {
            hadiah = "tidak mendapat hadiah";
        }

        // Menampilkan hadiah yang didapat
        System.out.println("Selamat.... Anda " + hadiah);

        // Menampilkan ucapan terima kasih
        System.out.println("Terima Kasih Anda sudah belanja di Kharisna Agung Plaza");
    }
}
