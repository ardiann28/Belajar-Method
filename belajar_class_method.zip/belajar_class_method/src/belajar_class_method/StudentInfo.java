/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package belajar_class_method;

/**
 *
 * @author EC
 */
public class StudentInfo {
    public static void main(String[] args) {
        // Deklarasi variabel
        String fName = "Lisa";
        String lName = "Palombo";
        int stuId = 123456789;
        String stuStatus = "Active";

        // Menampilkan informasi siswa
        System.out.println("Student Name: " + fName + " " + lName);
        System.out.println("Student ID: " + stuId);
        System.out.println("Student Status: " + stuStatus);
    }
}

        
              
