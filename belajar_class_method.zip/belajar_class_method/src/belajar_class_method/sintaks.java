/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package belajar_class_method;

import java.util.Scanner;

/**
 *
 * @author EC
 */
public class sintaks {
//    public static void main(String[] args) {
//        int nilai;
//        String grade;
//        Scanner scan =  new Scanner(System.in);
//        
//        System.out.print("inputkan nilai; ");
//        nilai = scan.nextInt();
//        
//        if (nilai >= 90){
//            grade= "A";
//        }else if (nilai >= 80)  {
//             grade= "B+";
//        }else if (nilai >= 70)  {
//             grade= "B";
//         }else if (nilai >= 60)  {
//             grade= "C+";
//         }else if (nilai >= 30)  {
//             grade= "C";
//           }else if (nilai >= 10)  {
//             grade= "D";
//        }else {
//             grade= "E";      
//        }
//        
//        System.out.println ("Grade: " + grade);
//    }
//}

public static void main(String[] args) {
         String lampu;
         Scanner scan = new Scanner(System.in);

        System.out.print("Inputkan nama warna: ");
        lampu = scan.nextLine();

     switch (lampu) {
        case "merah":
            System.out.println("Lampu merah, berhenti!");
        break;
        case "kuning":
            System.out.println("Lampu kuning, harap hati-hati!");
        break;
        case "hijau":
            System.out.println("Lampu hijau, silahkan jalan");
        break;
        default:
            System.out.println("Warna lampu salah");
     }
}
}