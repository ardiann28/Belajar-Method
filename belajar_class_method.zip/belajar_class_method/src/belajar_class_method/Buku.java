/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package belajar_class_method;

/**
 *
 * @author EC
 */
public class Buku {
    public static void main(String[] args) {
        book javabook = new book();
        javabook.set(1000000, 2000);
        javabook.show();
    }
}

