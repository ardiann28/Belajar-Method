/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package input_keyboard;

import java.util.Scanner;

/**
 *
 * @author EC
 */
public class prak_scanner {
    public static void main(String[] args) {

//Buat scanner
        Scanner sl = new Scanner(System.in);

//Ambil nilai dars Keyboard
        System.out.print("Masukkan nila1= ");
        int nilai1 =sl.nextInt();
        System.out.print("Masukkan nilai2= ");
        int nilai2 = sl.nextInt();
        
        int jumlah = nilai1 + nilai2 ;
        System.out.println("Jumlah= " + jumlah) ;
}
}
